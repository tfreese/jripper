package org.musicbrainz.ws;

public class ReleaseNotFoundException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public ReleaseNotFoundException(String string) {
    super(string);
  }

}
